package com.adavec.prefacturacion;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class PrefacturacionApplicationTests {

	@Test
	void contextLoads() {
	}

}
